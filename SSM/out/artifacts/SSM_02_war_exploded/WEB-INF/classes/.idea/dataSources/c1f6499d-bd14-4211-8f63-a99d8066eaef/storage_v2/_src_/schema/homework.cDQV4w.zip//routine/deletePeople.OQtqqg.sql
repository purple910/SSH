create
    definer = root@localhost procedure deletePeople(IN pno int)
begin
 delete from people where id = pno;
 end;

