create
    definer = root@localhost procedure queryCount(IN p_name varchar(20), OUT p_count int)
BEGIN

    SELECT count(1) INTO p_count
    FROM people
    WHERE name = p_name;

END;

