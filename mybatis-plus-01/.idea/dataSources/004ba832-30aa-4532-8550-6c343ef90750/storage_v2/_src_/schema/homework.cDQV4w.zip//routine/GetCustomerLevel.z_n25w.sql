create
    definer = root@localhost procedure GetCustomerLevel(IN p_customerNumber int, OUT p_customerLevel varchar(10))
BEGIN
    DECLARE creditlim DOUBLE;
 
    SELECT creditlimit INTO creditlim
    FROM customers
    WHERE customerNumber = p_customerNumber;
 
    SELECT CUSTOMERLEVEL(creditlim) 
    INTO p_customerLevel;
END;

